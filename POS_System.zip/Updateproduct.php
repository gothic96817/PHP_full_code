<?php 
include('connect.php');
if(isset($_REQUEST['pid']))
{
	$pid=$_REQUEST['pid'];
	$select="SELECT * FROM product p,brand b, category c
	where p.brandid= b.BrandID
	AND p.categoryid= c.categoryid
	AND productid='$pid'";
	$query=mysqli_query($connection,$select);
	$data=mysqli_fetch_array($query);
	$productid=$data['productid'];
	$productname=$data['productname'];
	$price=$data['price'];
	$qty=$data['quantity'];
	$des=$data['description'];
	$image1=$data['productimage'];
	$brandname = $data['BrandName'];
	$categoryname = $data['CategoryName'];
	$brandid = $data['BrandID'];
	$categoryid = $data['categoryid'];
}

if(isset($_POST['btnupdate']))
{
	$productid1=$_POST['txtproductid'];
	$brandid1=$_POST['txtbrandid'];
	$categoryid1=$_POST['txtcategoryid'];
	$brandname1=$_POST['txtbrandname'];
	$productname1=$_POST['txtproductname'];
	$categoryname1=$_POST['txtcategoryname'];
	$price1=$_POST['txtprice'];
	$qty1=$_POST['txtqty'];
	$des1=$_POST['txtdescription'];
	$image=$_FILES['txtimage']['name'];
	$Folder="BrandImage/";
	$filename=$Folder ."_".$image;
	$copied = copy($_FILES['txtimage']['tmp_name'], $filename);

	if (!$copied) 
	{
		echo "<p>cannot upload Image</p>";
		exit();
	}
	$update="UPDATE product set productname='$productname1',
	price = '$price1',
	quantity = '$qty1',
	description = '$des1',
	productimage = '$filename',
	BrandId='$brandid1',
	categoryid='$categoryid1'
	where productid='$productid1'";

	$query=mysqli_query($connection,$update);

	if($query)
	{
		echo "<script>alert('Product Update Successful')</script>";
		echo "<script>window.location='product.php'</script>";
	}
	else
	{
		echo mysqli_error($connection);
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="Updateproduct.php" method="POST" enctype="multipart/form-data">
		<input type="hidden" name="txtproductid" value="<?php echo $productid ?>">
		<input type="hidden" name="txtbrandid" value="<?php echo $brandid ?>">
		<input type="hidden" name="txtcategoryid" value="<?php echo $categoryid ?>">
		<table border="1" align="center">
			<tr>
				<th colspan="2">Product Update Register</th>
			</tr>

			<tr>
				<td>Product Name</td>
				<td>
					<input type="text" name="txtproductname" value="<?php echo $productname ?>">
				</td>
			</tr>

			<tr>
				<td>Brand Name</td>
				<td>
					<input type="text" name="txtbrandname" value="<?php echo $brandname ?>">
				</td>
			</tr>

			<tr>
				<td>Category Name</td>
				<td>
					<input type="text" name="txtcategoryname" value="<?php echo $categoryname ?>">
				</td>
			</tr>

			<tr>
				<td>Price</td>
				<td>
					<input type="text" name="txtprice" value="<?php echo $price ?>">
				</td>
			</tr>

			<tr>
				<td>Quantity</td>
				<td>
					<input type="number" name="txtqty" value="<?php echo $qty ?>">
				</td>
			</tr>

			<tr>
				<td>Description</td>
				<td>
					<textarea name="txtdescription">
						<?php echo $des ?>
					</textarea>
				</td>
			</tr>

			<tr>
				<td>Product Image</td>
				<td>
					<img src="<?php echo $image1 ?>">
					<input type="file" name="txtimage">
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
					
					<input type="submit" name="btnupdate" value="Update">
				</td>
			</tr>
		</table>
	</form>
	<link rel="stylesheet" href="css/style.css">
</body>
</html>