<?php
	session_start();
	include 'connect.php';
	if(isset($_POST['btnlogin'])) 
	{
		$email=$_POST['txtemail'];
		$password=$_POST['txtpassword'];

		$select="SELECT * FROM staff WHERE Email='$email' and Password='$password'";
		$query=mysqli_query($connection,$select);
		$count=mysqli_num_rows($query);
		if($count>0) 
		{
			echo "<script>alert('Staff Login Successfully.')</script>";
			echo "<script>window.location='staffhome.php'</script>";
		}
		else
		{
		$select1="SELECT * FROM customer where Email='$email' and Password='$password'";
		$query1=mysqli_query($connection,$select1);
		$count1=mysqli_num_rows($query1);
		if($count1>0)
		{
			$data=mysqli_fetch_array($query1);
			$customerid=$data['CustomerID'];
			$customername=$data['CustomerName'];
			$_SESSION['cid']=$customerid;
			$_SESSION['cname']=$customername;
			echo "<script>alert('Customer Login Successful')</script>";
			echo "<script>window.location='index.php'</script>";
		}	
	}
	}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title></title>
 </head>
 	<style>
 		body 
 		{
 			max-width: max-content;
 			margin: auto;
 			background-color: skyblue;
 		}
 	</style>
 <body>
 	
 	<fieldset>
 		<legend align="center">Login Form</legend>
 		<form action="login.php" method="POST">
 			<table align="center">
 				<tr>
 					<td>Email</td>
 					<td><input type="text" name="txtemail" required placeholder="Enter Email Address"></td>
 				</tr>

 				<tr>
 					<td>Password</td>
 					<td><input type="password" name="txtpassword" required placeholder="Enter Password"></td>
 				</tr>

 				<tr>
 					<td></td>
 					<td><input type="submit" name="btnlogin" value="Login">
 						<input type="reset" value="Clear">
 					</td>
 				</tr>
 			</table>
 		</form>
 	</fieldset>
 	<link rel="stylesheet" href="css/style.css">
 </body>
 </html>