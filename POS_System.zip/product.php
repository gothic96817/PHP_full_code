<?php 
	include('connect.php');
	if(isset($_POST['btnrecord']))
	{
		$productname=$_POST['txtproductname'];
		$brandname=$_POST['txtbrandname'];
		$categoryname=$_POST['txtcategoryname'];
		$price=$_POST['txtprice'];
		$quantity=$_POST['txtquantity'];
		$description=$_POST['txtdescription'];
		//////////////////////////////////Image/////////////////////////////////
		$image=$_FILES['txtproductimage']['name'];
		$Folder="Image/";
		$filename=$Folder . '_' . $image; //Images/_a.jpg
		$imagefile=copy($_FILES['txtproductimage']['tmp_name'],$filename);
		if(!$imagefile)
		{
			echo "<p>Cannot Upload  Product Image</p>";
			exit();
		}

	/////////////////////////////////////////////////////////////////////////

		$select="SELECT * FROM Product where productname='$productname'";
		$query1=mysqli_query($connection,$select);
		$count=mysqli_num_rows($query1);
		if($count>0)
		{
			echo "<script>alert('Product Name Duplicate')</script>";
		}
		else
		{

		$insert="INSERT INTO product(productname,categoryid,brandid,price,quantity,description,productimage)
		values('$productname','$categoryname','$brandname','$price','$quantity','$description','$filename')";
		$query=mysqli_query($connection,$insert);
		if($query)
		{
			echo "<script>alert('Product Save Successfully')</script>";
		}
	}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="product.php" method="POST" enctype="multipart/form-data">
	<a href='staffhome.php'>Home</a> |
	<a href='brand.php'>Brand</a> | 
	<a href='category.php'>Category</a> | 
	<a href='product.php'>Product</a> | 
	<a href="supplier.php">Supplier</a> | 
	<a href='purchase.php'>Purchase</a> | 
	<a href='logout.php'>Logout</a>	
		<table border="1" align="center">
			<tr>
				<th colspan="2">Product Entry</th>
				
			</tr>
			<tr>
				<td>Product Name</td>
				<td>
					<input type="text" name="txtproductname" required placeholder="Enter Product Name">
				</td>
			</tr>
			<tr>
				<td>Brand Name</td>
				<td>
					<select name="txtbrandname">
						<?php 
							$select="SELECT * FROM brand";
							$query=mysqli_query($connection,$select);
							$count=mysqli_num_rows($query);
							if($count>0)
							{
								for ($i=0; $i <$count ; $i++) 
								{ 
									$data=mysqli_fetch_array($query);
									$brandid=$data['BrandID'];
									$brandname=$data['BrandName'];
									echo "<option value='$brandid'>$brandname</option>";
								}
							}

						 ?>

					</select>
				</td>
			</tr>
			<tr>
				<td>Category Name</td>
				<td>
				<select name="txtcategoryname">
						<?php 
							$select="SELECT * FROM category";
							$query=mysqli_query($connection,$select);
							$count=mysqli_num_rows($query);
							if($count>0)
							{
								for ($i=0; $i <$count ; $i++) 
								{ 
									$data=mysqli_fetch_array($query);
									$categoryid=$data['categoryid'];
									$categoryname=$data['CategoryName'];
									echo "<option value='$categoryid'>$categoryname</option>";
								}
							}

						 ?>

					</select>
				</td>
			</tr>
			<tr>
				<td>Product Image</td>
				<td>
					<input type="file" name="txtproductimage" required placeholder="Choose Product Image">
				</td>
			</tr>
			<tr>
				<td>Price</td>
				<td>
					<input type="text" name="txtprice" required placeholder="Enter Product Price">
				</td>
			</tr>
			<tr>
				<td>Quantity</td>
				<td>
					<input type="number" name="txtquantity" required placeholder="Enter Product Quantity">
				</td>
			</tr>
			<tr>
				<td>Description</td>
				<td>
					<textarea name="txtdescription" required placeholder="Enter Services">
						
					</textarea>
				</td>
			</tr>
			
			<tr>
				<td></td>
				<td>
					<input type="submit" name="btnrecord" value="Record">
				</td>
			</tr>
		</table>

		<table border="1" align="center">
			<tr>
				<th>Product ID</th>
				<th>Product Name</th>
				<th>Brand Name</th>
				<th>Category Name</th>
				<th>Product Image</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Description</th>
				<th>Action</th>
			</tr>
			

	
		<?php 

		$select="Select * from product p,brand b, category c
		where p.brandid=b.brandid
		AND p.categoryid=c.categoryid";
		$query=mysqli_query($connection,$select);
		$count=mysqli_num_rows($query);
		if($count>0)
		{
			for ($i=0; $i <$count ; $i++) 
			{ 
				$data=mysqli_fetch_array($query);
				$productid=$data['productid'];
				$productname=$data['productname'];
				$brandname=$data['BrandName'];
				$categotryname=$data['CategoryName'];
				$productimage=$data['productimage'];
				$price=$data['price'];
				$quantity=$data['quantity'];
				$description=$data['description'];
				echo "<tr>
					<td>$productid</td>
					<td>$productname</td>
					<td>$brandname</td>
					<td>$categotryname</td>
					<td><img src='$productimage' width='100px' height='100px'></td>
					<td>$price</td>
					<td>$quantity</td>
					<td>$description</td>
					<td>
					<a href='Updateproduct.php?pid=$productid'>Update</a> 
					| 
					<a href='Deleteproduct.php?pid=$productid'>Delete</a></td>

				</tr>";
			}
		}
		 ?>
		

	</table>
	</form>
	<link rel="stylesheet" href="css/style.css">
</body>
</html>