<?php
include ('connect.php');
if (isset($_REQUEST['orderid'])) 
{

	$orderid=$_REQUEST['orderid'];
	$Select="select * from orders o,customer c, orderdetail od,product p 
	where o.customerid=c.customerid
	AND o.orderid=od.orderid
	AND od.productid=p.productid
	AND o.orderid='$orderid'";
	$query=mysqli_query($connection,$Select);
	$count=mysqli_num_rows($query);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form>
		<a href='staffhome.php'>Home</a> |
		<a href='brand.php'>Brand</a> | 
		<a href='category.php'>Category</a> | 
		<a href='product.php'>Product</a> | 
		<a href="supplier.php">Supplier</a> | 
		<a href='purchase.php'>Purchase</a> | 
		<a href='logout.php'>Logout</a>	

		<table border="1" width="500px">
			<tr>
				<td>Product Name</td>
				<td>Unit Price</td>
				<td>Unit Quantity</td>
			</tr>

			<?php 


					for ($i=0; $i <$count ; $i++) 
					{ 						
							$data=mysqli_fetch_array($query);

							$productname=$data['productname'];
							$unitprice=$data['unitprice'];
							$unitquantity=$data['unitquantity'];
							$orderdate=$data['orderdate'];
							$customername=$data['CustomerName'];
							$totalamount=$data['totalamount'];
							$totalquantity=$data['totalquantity'];
										
			 ?>
			<tr>
				<td>
					<?php echo $productname ?>
				</td>
				<td>
					<?php echo $unitprice ?>
				</td>
				<td>
					<?php echo $unitquantity ?>
				</td>
			</tr>

			<?php 
				}
			 ?>
			 			<tr>
				<td colspan="3">
					Order ID :<?php echo $orderid ?><p>
					Order Date :<?php echo $orderdate  ?><p>
					Customer Name : <?php echo $customername ?>
				</td>
			</tr>
			 <tr>
			 	<td colspan="3">
			 		Total Amount :<?php echo $totalamount ?><p>
			 		Total Quantity :<?php echo $totalquantity ?>
			 	</td>
			 </tr>
			 
		</table>
	</form>
	<link rel="stylesheet" href="css/style.css">
</body>
</html>