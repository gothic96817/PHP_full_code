<?php 
	include('connect.php');
	if (isset($_POST['btnregister'])) 
	{
		$BrandName = $_POST['txtbrandname'];
		$Exportdate = $_POST['txtedate'];
		$Price = $_POST['txtprice'];
		$Quantity = $_POST['txtqty'];

		$BrandImage = $_FILES['txtimage'];
		$folder = "BrandImage/";
		$filename = $folder ."_". $BrandImage;

		$copied = copy($_FILES['txtimage']['tmp_name'], $filename);
		if(!$copied)
		{
			echo "<p>Cannot Upload Photo.</p>";
			exit();
		}

		$insert = "INSERT INTO Brand(BrandName,ExportDate,Price,BrandImage)
		VALUES ('$BrandName','$ExportDate','$Price','$filename')";

		$query = mysqli_query($connection,$insert);

		if($query) 
		{
			echo "<script>alert('Brand Recorded.')</script>";
			echo "<script>window.location='staffhome.php'</script>";
		}
		else
		{
			echo "<script>window.alert('Something Went Wrong.')</script>";
		}	
	}

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
	<style>
		body 
		{
			max-width: max-content;
			margin: auto;
		}
	</style>
<body>
 	<form action="brand.php" method="POST" enctype="multipart/form-data">
 	<a href='staffhome.php'>Home</a> |
	<a href='brand.php'>Brand</a> | 
	<a href='category.php'>Category</a> | 
	<a href='product.php'>Product</a> | 
	<a href="supplier.php">Supplier</a> | 
	<a href='purchase.php'>Purchase</a> | 
	<a href='logout.php'>Logout</a>	
 		<table border="1" align="center">
 			<tr>
 				<th colspan="2">Brand Register</th>
 			</tr>

 			<tr>
 				<td>Brand Name</td>
 				<td>
 					<input type="text" name="txtbrandname" required placeholder="Enter Brand Name">
 				</td>
 			</tr>

 			<tr>
 				<td>Export Date</td>
 				<td>
 					<input type="date" name="txtedate" required placeholder="Choose date">
 				</td>
 			</tr>

 			<tr>
 				<td>Price</td>
 				<td>
 					<input type="text" name="txtprice" required placeholder="Enter Price">
 				</td>
 			</tr>

 			<tr>
 				<td>Quantity</td>
 				<td>
 					<input type="number" name="txtqty" required placeholder="Enter Quantity">
 				</td>
 			</tr>

 			<tr>
 				<td>Brand Image</td>
 				<td>
 					<input type="file" name="txtimage" required>
 				</td>
 			</tr>

 			<tr>
 				<td></td>
 				<td>
 					<input type="submit" name="btnregister" value="Register">
 					<input type="reset" value="Clear">
 				</td>
 			</tr>
 		</table>
 	</form>
 	<link rel="stylesheet" href="css/style.css">
</body>
</html>

