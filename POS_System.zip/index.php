<?php 
	session_start();
	include('connect.php');

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table style="background-color: white;">
		<tr>
			<td colspan="5">
				<h1>The Online Shopping and Ordering System of IT Sales and Services</h1>
			</td>

		</tr>

		<tr>
			<td>
				<a href="index.php">Home</a>
			</td>
			<td>
				<a href="customer.php">Customer Register</a>
			</td>
			
			<td>
				<a href="shoppingcart.php">Shopping Cart</a>
			</td>
			<td>
				<a href="logout.php">Logout</a>
			</td>
		</tr>
	</table>
<form>
	<fieldset>
		<legend>Product List:</legend>
		<table align="center" cellpadding="10px">
		<?php
		$query="SELECT * FROM product ORDER BY productid DESC";
		$ret=mysqli_query($connection,$query);
		$count=mysqli_num_rows($ret);
		if($count<1)
		{
			echo "<p>No Product Data Found.</p>";
			exit();
		}
		for ($a=0; $a <$count ; $a+=3) 
		{ 
			$query1="SELECT * FROM product ORDER BY productid DESC LIMIT $a,3";
			$ret1=mysqli_query($connection,$query1);
			$count1=mysqli_num_rows($ret1);
			echo "<tr>";
			for ($b=0; $b <$count1 ; $b++) 
			{ 
				$arr=mysqli_fetch_array($ret1);
				$productid=$arr['productid'];
				$productname=$arr['productname'];
				$price=$arr['price'];
				$image=$arr['productimage'];
				
				?>
				<td>
					<img src="<?php echo $image ?>" width="200px" height="200px"/><br/>
					<b><?php echo $productname ?></b><br/>
					<b><?php echo $price ?></b>MMK<br/>
					<a href="productdetail.php?productid=<?php echo $productid ?>" style="color:red">Detail</a>
				</td>
        <?php
			}
			echo "</tr>";
		}

		?>	
		</table>
	</fieldset>
</form>
<link rel="stylesheet" href="css/style.css">
</body>
</html>