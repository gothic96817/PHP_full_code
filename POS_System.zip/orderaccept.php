<?php
include ('connect.php');
if (isset($_REQUEST['orderid'])) 
{
	$oid=$_REQUEST['orderid'];
	$Select="Update orders set orderstatus='confirm' where orderid='$oid'";
	$query=mysqli_query($connection,$Select);
	if ($query) 
	{
		echo "<script>
		alert('Order Confirm')
		window.location='staffhome.php'</script>";
	}
}
?>