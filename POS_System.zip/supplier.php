<?php 
	include('connect.php');
	if (isset($_POST['btnregister'])) 
	{
		$SupplierName = $_POST['txtsupname'];
		$Address = $_POST['txtaddress'];
		$PhoneNumber = $_POST['txtphonenumber'];
		$Email = $_POST['txtemail'];

		$insert = "INSERT INTO supplier(suppliername,address,phonenumber,email)
		VALUES ('$SupplierName','$Address','$PhoneNumber','$Email')";

		$query = mysqli_query($connection,$insert);

		if($query)
		{
			echo "<script>alert('Supplier Added.')</script>";
			echo "<script>window.location='staffhome.php'</script>";
		}
		else
		{
			echo "<script>window.alert('Something Went Wrong.')</script>";
		}	
	}

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
	<style>
		body 
		{
			max-width: max-content;
			margin: auto;
		}
	</style>
<body>
 	<form action="supplier.php" method="POST">
 	<a href='staffhome.php'>Home</a> |
	<a href='brand.php'>Brand</a> | 
	<a href='category.php'>Category</a> | 
	<a href='product.php'>Product</a> | 
	<a href="supplier.php">Supplier</a> | 
	<a href='purchase.php'>Purchase</a> | 
	<a href='logout.php'>Logout</a>	
 		<table border="1" align="center">
 			<tr>
 				<th colspan="2">Supplier Register</th>
 			</tr>

 			<tr>
 				<td>Supplier Name</td>
 				<td>
 					<input type="text" name="txtsupname" required placeholder="Enter Supplier Name">
 				</td>
 			</tr>

 			<tr>
 				<td>Address</td>
 				<td>
 					<input type="text" name="txtaddress" required placeholder="Enter Address">
 				</td>
 			</tr>

 			<tr>
 				<td>Phone Number</td>
 				<td>
 					<input type="text" name="txtemail" required placeholder="Enter Phone Number">
 				</td>
 			</tr>

 			<tr>
 				<td>Email</td>
 				<td>
 					<input type="text" name="txtemail" required placeholder="Enter Email">
 				</td>
 			</tr>

 			<tr>
 				<td></td>
 				<td>
 					<input type="submit" name="btnregister" value="Register">
 					<input type="reset" value="Clear">
 				</td>
 			</tr>
 		</table>
 	</form>
 	<link rel="stylesheet" href="css/style.css">
</body>
</html>

