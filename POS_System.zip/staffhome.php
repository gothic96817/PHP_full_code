<?php 
	include('connect.php');

	if(isset($_POST['btnSearch']))
	{
		$rdoSearchType=$_POST['rdoSearchType'];

	if($rdoSearchType==1) 
		{
			$OrderID=$_POST['cboOrderID'];

			$Squery="SELECT o.*,c.customerid,c.customername
					 FROM orders o,customer c 
					 WHERE o.orderid='$OrderID'
					 AND o.customerid=c.customerid";
			$result=mysqli_query($connection,$Squery);
		}
		elseif ($rdoSearchType==2) 
		{
			$txtFrom=date('Y-m-d',strtotime($_POST['txtFrom']));
			$txtTo=date('Y-m-d',strtotime($_POST['txtTo']));

			$Squery="SELECT o.*,c.customerid,c.customername
					 FROM orders o,customer c 
					 WHERE o.orderdate BETWEEN '$txtFrom' AND '$txtTo'
				 	AND o.customerid=c.customerid";
			$result=mysqli_query($connection,$Squery);
		}
		else
		{
			$Squery="SELECT o.*,c.customerid,c.customername
					 FROM orders o,customer c 
					 WHERE o.customerid=c.customerid";
			$result=mysqli_query($connection,$Squery);
		}
	}
		elseif(isset($_POST['btnShowAll']))
		{
			$Squery="SELECT o.*,c.customerid,c.customername
					 FROM orders o,customer c 
					 WHERE o.customerid=c.customerid";
			$result=mysqli_query($connection,$Squery);
		}
		else
		{
			$todayDate=date('Y-m-d');

			$Squery="SELECT o.*,c.customerid,c.customername
					 FROM orders o,customer c 
					 WHERE o.orderdate='$todayDate'
					 AND o.customerid=c.customerid";
			$result=mysqli_query($connection,$Squery);
		}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="staffhome.php" method="POST">
	<a href='staffhome.php'>Home</a> |
	<a href='brand.php'>Brand</a> | 
	<a href='category.php'>Category</a> | 
	<a href='product.php'>Product</a> | 
	<a href="supplier.php">Supplier</a> | 
	<a href='purchase.php'>Purchase</a> | 
	<a href='logout.php'>Logout</a>	
	<fieldset>
		<table border="1" align="center">
			<tr>
				<td align="center" colspan="6"><h1>Search:</h1> 
				</td>
			</tr>
			<tr>
				<td>
					<input type="radio" name="rdoSearchType" value="1" checked />Search by OrderID
				<br/>
				<select name="cboOrderID">
				<option>Choose OrderID</option>
			<?php  
			$query="SELECT o.*,c.customerid,c.customername
					FROM orders o,customer c 
					WHERE o.customerid=c.customerid";
			$ret=mysqli_query($connection,$query);
			$count=mysqli_num_rows($ret);

			for($i=0;$i<$count;$i++) 
			{ 
				$arr=mysqli_fetch_array($ret);
				$OrderID=$arr['orderid'];
				$CustomerName=$arr['customername'];	

				echo "<option value='$OrderID'>" . $OrderID ."</option>";
			}

			?>
			</select>
		</td>

		<td>
			<input type="radio" name="rdoSearchType" value="2"/>Search by Date
		<br/>
			From:<input  type="date" name="txtFrom" value="<?php echo date('d-m-Y') ?>" />
			To  :<input type="date" name="txtTo" value="<?php echo date('d-m-Y') ?>"  />
		</td>
		<td>
		<br/>
			<input type="submit" name="btnSearch" value="Search"/>
			<input type="submit" name="btnShowAll" value="Show All"/>

			</td>
		</tr>
	</table>
</fieldset>


<fieldset>
	<legend>Search Results :</legend>
	<?php  
		$count=mysqli_num_rows($result);

		if($count==0) 
		{
			echo "<p>No Order Record Found.</p>";
			exit();
		}
	?>
	<table id="tableid" class="display" align="center" border="1px">
		<thead>
		<tr>
			<th>Order ID</th>
			<th>Order Date</th>
			<th>Customer Name</th>
			<th>Total Amount</th>
			<th>Total Quantity</th>
			<th>Status</th>
			<th>Action</th>
		</tr>
		</thead>
	<tbody>	
	<?php
		for($i=0;$i<$count;$i++) 
		{
			$arr=mysqli_fetch_array($result);
			$OrderID=$arr['orderid'];
			$CustomerName=$arr['customername'];
			$orderdate=$arr['orderdate'];
			$totalamount=$arr['totalamount'];
			$totalquantity=$arr['totalquantity'];
			$orderstatus=$arr['orderstatus'];
				echo "<tr>";
				echo "<td>$OrderID</td>";
				echo "<td>$orderdate</td>";
				echo "<td> $CustomerName </td>";	
				echo "<td>$totalamount</td>";
				echo "<td>$totalquantity</td>";
				echo "<td>$orderstatus</td>";
				echo "<td><a href='orderaccept.php?orderid=$OrderID' style='color:red'>Accept</a> |
				<a href='orderdetail.php?orderid=$OrderID' style='color:red'>Detail</a>
				</td>";
				echo "</tr>";
			}
			?>
		</tbody>
		</table>
		</fieldset>
	</form>
	<link rel="stylesheet" href="css/style.css">
</body>
</html>