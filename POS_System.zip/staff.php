<?php 
	include('connect.php');
	if(isset($_POST['btnsave'])) 
	{
		$StaffName = $_POST['txtstaffname'];
		$Position = $_POST['txtposition'];
		$StartDate = $_POST['txtstartdate'];
		$ServiceDay = $_POST['txtservice'];
		$Email = $_POST['txtemail'];
		$Password = $_POST['txtpassword'];
		$Phone = $_POST['txtphone'];
		$Address = $_POST['txtaddress'];
		$Status = $_POST['txtstatus'];

		$StaffProfile = $_FILES['txtprofile']['name'];
		$folder = "Image/";
		$filename = $folder ."_".$StaffProfile;

		$copied = copy($_FILES['txtprofile']['tmp_name'], $filename);
		if(!$copied)
		{
			echo "<p>Cannot Upload Photo.</p>";
			exit();
		}
		


		$insert = "INSERT INTO Staff(StaffName,StaffProfile,Position,StartDate,ServiceDay,Email,Password,Phone,Address,Status) 
		VALUES('$StaffName','$filename', '$Position', '$StartDate','$ServiceDay','$Email', '$Password', '$Phone', '$Address', '$Status')";
		$query = mysqli_query($connection,$insert);
		if ($query) 
		{
			echo "<script>alert('Staff Login Successfully.')</script>";
			echo "<script>window.location='index.php'</script>";
		}
		else
		{
			echo "<script>window.alert('Something Went Wrong.')</script>";
		}
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
	<style>
		body 
		{
			max-width: max-content;
			margin: auto;
		}
	</style>
<body>
	<form action="staff.php" method="POST" enctype="multipart/form-data">
		<table border="1" align="center">

			<tr>
				<th colspan="2">Staff Register</th>
			</tr>
			
			<tr>
				<td>Staff Name</td>
				<td>
					<input type="text" name="txtstaffname" required placeholder="Enter your Name">
				</td>
			</tr>

			<tr>
				<td>Staff Profile</td>
				<td>
					<input type="file" name="txtprofile" required placeholder="Choose Staff Profile">
				</td>
			</tr>

			<tr>
				<td>Position</td>
				<td>
					<select name="txtposition" required>
						<option>--Choose Position--</option>
						<option>Manager</option>
						<option>Admin</option>
						<option>Sale</option>
					</select>
				</td>
			</tr>

			<tr>
				<td>Start Date</td>
				<td>
					<input type="date" name="txtstartdate" required placeholder="Choose Start Date">
				</td>
			</tr>

			<tr>
				<td>Service Day</td>
				<td>
					<input type="date" name="txtservice" required placeholder="Choose Service Day">
				</td>
			</tr>

			<tr>
				<td>Email</td>
				<td>
					<input type="text" name="txtemail" placeholder="Enter Email" required>
				</td>
			</tr>

			<tr>
				<td>Password</td>
				<td>
					<input type="password" name="txtpassword" placeholder="Enter Password" required>
				</td>
			</tr>

			<tr>
				<td>Phone Number</td>
				<td>
					<input type="text" name="txtphone" required placeholder="Enter your phone number">
				</td>
			</tr>

			<tr>
				<td>Address</td>
				<td>
					<textarea name="txtaddress" required></textarea>
				</td>
			</tr>

			<tr>
				<td>Status</td>
				<td>
					<select name="txtstatus" required>
						<option>Present</option>
						<option>Absent</option>
					</select>
				</td>
			</tr>

			<tr>
				<td></td>
				<td>
					<input type="submit" name="btnsave" value="Register">
					<input type="reset" value="Clear">
				</td>
			</tr>
		</table>
	</form>
	<link rel="stylesheet" href="css/style.css">
</body>
</html>