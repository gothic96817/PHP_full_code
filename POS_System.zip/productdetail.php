<?php 
session_start();
include('connect.php');
if(!isset($_SESSION['cid']))
{
	echo "<script>alert('Pls Login Again')</script>";
    echo "<script>window.location='login.php'</script>";

}

if (isset($_REQUEST['productid']))
{
	$productid=$_REQUEST['productid'];
	$query="SELECT p.*,b.brandid,b.brandname,c.categoryid,c.categoryname
    FROM product p,brand b,category c
    WHERE p.brandid=b.brandid
    AND p.categoryid=c.categoryid
    AND p.productid='$productid'";
    $ret=mysqli_query($connection,$query);
    $arr=mysqli_fetch_array($ret);

    $productid=$arr['productid'];
    $productname=$arr['productname'];
    $price=$arr['price'];
    $quantity=$arr['quantity'];
    $description=$arr['description'];
    $brandname=$arr['brandname'];
    $categoryname=$arr['categoryname'];
    $image1=$arr['productimage'];
}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	<table style="background-color: white;">
		<tr>
			<td colspan="5">
				<h1>The Online Shopping and Ordering System of IT Sales and Services</h1>
			</td>

		</tr>

		<tr>
			<td>
				<a href="index.php">Home</a>
			</td>
			<td>
				<a href="customer.php">Customer Register</a>
			</td>
			
			<td>
				<a href="shoppingcart.php">Shopping Cart</a>
			</td>

			<td>
				<a href="checkout.php">Check out</a>
			</td>

			<td>
				<a href="logout.php">Logout</a>
			</td>
		</tr>
	</table>
	<form action="shoppingcart.php" method="get">
		<input type="hidden" name="productid" value="<?php echo $productid ?>"/>
		<input type="hidden" name="action" value="buy" />
		
		<fieldset>
			<legend>Product Detail of <?php echo $productname ?></legend>
			<table align="center">
				<tr>
					<td>
						<img src="<?php echo $image1 ?>" width="$400px" height="400px" id="ImgPhoto"/><br/>
					</td>
						<td>
					<table>
						<tr>
							<td>Product Name</td>
							<td>
							:<b><?php echo $productname ?></b>
						</td>
						</tr>
						<tr>
							<td>Brand Name</td>
							<td>
							:<b><?php echo $brandname ?></b>
						</td>
						</tr>
						<tr>
							<td>Category Name</td>
							<td><?php echo $categoryname ?></td>
						</tr>
						<tr>
							<td>Price</td>
							<td>
								:<b style="colour:blue;"><?php echo $price ?></b>MMK
							</td>
						</tr>
						<tr>
							<td>Quantity</td>
							<td>
								:<b>
								<?php 
									if($quantity<1) 
									{
									echo "Out Of Stock";
									exit(); 
									}
									echo $quantity ?></b>Pcs
							</td>
						</tr>
						<tr>
							<td>Buying Quantity</td>
							<td>
								:<input type="number" name="txtBuyQuantity" value="1" min="1" max="20"/>
								<input type="submit" name="btnAdd" value="Add"/>
							</td>
						</tr>
					</table>
					</td>
					</tr>
					<tr>
						<td colspan="2">
					<hr/>
						Description
					<hr/>
						<b><?php echo $description ?></b>
					</td>
				</tr>
			</table>
		</fieldset>		
	</form>
	<link rel="stylesheet" href="css/style.css">
 </body>
 </html>