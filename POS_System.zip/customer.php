<?php 
	include('connect.php');
	if (isset($_POST['btnregister'])) 
	{
		$CustomerName = $_POST['txtCustomerName'];
		$dob = $_POST['txtdob'];
		$email = $_POST['txtemail'];
		$password = $_POST['txtpassword'];
		$Phone = $_POST['txtPhone'];
		$Address = $_POST['txtAddress'];

		$insert = "INSERT INTO Customer(CustomerName,DateOfBirth,Email,Password,Phone,Address)
		VALUES ('$CustomerName','$dob','$email','$password','$Phone','$Address')";

		$query = mysqli_query($connection,$insert);

		if($query) 
		{
			echo "<script>alert('Customer Register Successfully.')</script>";
			echo "<script>window.location='index.php'</script>";
		}
		else
		{
			echo "<script>window.alert('Something Went Wrong.')</script>";
		}	
	}

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
	<style>
		body 
		{
			max-width: max-content;
			margin: auto;
		}
	</style>
<body>
 	<form action="customer.php" method="POST">
 		<table border="1" align="center">
 			<tr>
 				<th colspan="2">Customer Register</th>
 			</tr>

 			<tr>
 				<td>Customer Name</td>
 				<td>
 					<input type="text" name="txtCustomerName" required placeholder="Enter your Name">
 				</td>
 			</tr>

 			<tr>
 				<td>Date of Birth</td>
 				<td>
 					<input type="date" name="txtdob" required placeholder="Choose your date of birth">
 				</td>
 			</tr>
 			<tr>
 				<td>Email</td>
 				<td>
 					<input type="text" name="txtemail" required placeholder="Enter Email">
 				</td>
 			</tr>

 			<tr>
 				<td>Password</td>
 				<td>
 					<input type="password" name="txtpassword" required>
 				</td>
 			</tr>

 			<tr>
 				<td>Phone</td>
 				<td>
 					<input type="text" name="txtPhone" required placeholder="Enter your Phone Nmber">
 				</td>
 			</tr>

 			<tr>
 				<td>Address</td>
 				<td>
 					<input type="text" name="txtAddress" required placeholder="Enter your address">
 				</td>
 			</tr>

 			<tr>
 				<td></td>
 				<td>
 					<input type="submit" name="btnregister" value="Register">
 					<input type="reset" value="Clear">
 				</td>
 			</tr>
 		</table>
 	</form>
 	<link rel="stylesheet" href="css/style.css">
</body>
</html>

