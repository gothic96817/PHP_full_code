c<?php 
include('connect.php');
if(isset($_REQUEST['pid']))
{
	$pid=$_REQUEST['pid'];
	$delete="DELETE FROM product where productid='$pid'";
	$query=mysqli_query($connection,$delete);
	if($query)
	{
		echo "<script>alert('Product Delete Successful')</script>";
		echo "<script>window.location='product.php'</script>";
	}
}
?>