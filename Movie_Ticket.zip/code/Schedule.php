 <?php 
	session_start();
	include('connect.php');
	include('autoidfunction.php');
	include('schedulefunction.php');
if (isset($_GET['btnsave'])) 
{
	
	$StaffID=$_GET['cboStaffID'];
	$txtscheduleid=$_GET['txtscheduleid'];
	//$govtax=CalculateTax();
	$txtscheduledate=$_GET['txtscheduledate'];

	$Status="Pending";
	$insert_pur="INSERT INTO Movie_Schedule
	(ScheduleID,ScheduleDate,StaffID,Status)values
	('$txtscheduleid','$txtscheduledate','$StaffID','$Status')";
	$ret=mysqli_query($connection,$insert_pur);

$size=count($_SESSION['schedulefunction']);
for ($i=0; $i <$size ; $i++) 
{ 
		$cboMovieID=$_SESSION['schedulefunction'][$i]['cboMovieID'];
	  	$MovieName=$_SESSION['schedulefunction'][$i]['MovieName'];
	  	$MovieImage=$_SESSION['schedulefunction'][$i]['MovieImage'];
	  	$cboTheatreID=$_SESSION['schedulefunction'][$i]['cboTheatreID'];
	  	$txtstartdate=$_SESSION['schedulefunction'][$i]['txtstartdate'];
	  	$txtstarttime=$_SESSION['schedulefunction'][$i]['txtstarttime'];
	  	$txtenddate=$_SESSION['schedulefunction'][$i]['txtenddate'];
	  	$txtendtime=$_SESSION['schedulefunction'][$i]['txtendtime'];
	  	$TheatreName=$_SESSION['schedulefunction'][$i]['TheatreName'];
	$inser_PDetail="INSERT INTO scheduledetail(ScheduleID,StartDate,EndDate,StartTime,EndTime,MovieID,TheatreID)
	VALUES('$txtscheduleid','$txtstartdate','$txtenddate','$txtstarttime','$txtendtime','$cboMovieID','$cboTheatreID')";
	$ret=mysqli_query($connection,$inser_PDetail);

}
if ($ret)
 {
	unset($_SESSION['schedulefunction']);
	echo "<script>window.alert('Schedule Process Complete.')</script>";
	echo "<script>window.location='Schedule.php'</script>";
}
else
{
	echo "<p>Something went wrongin purchase:". mysqli_error($connection)."</p>";
}
}


	if (isset($_GET['action'])) 
	{
	$action=$_GET['action'];
	if ($action==='add') 
	{
        $cboMovieID=$_GET['cboMovieID'];
		$cboTheatreID=$_GET['cboTheatreID'];
		$txtstartdate=$_GET['txtstartdate'];
		$txtstarttime=$_GET['txtstarttime'];
		$txtenddate=$_GET['txtenddate'];
		$txtendtime=$_GET['txtendtime'];
		Add($cboMovieID,$cboTheatreID,$txtstartdate,$txtstarttime,$txtendtime,$txtenddate);
	}
	elseif ($action==='remove') 
	{
		$cboMovieID=$_GET['cboMovieID'];
		Remove($cboMovieID);
	}
	elseif ($action==='clearall') 
	{
		ClearAll();
	}
}

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author"      content="Sergey Pozhilov (GetTemplate.com)">
	
	<title>Contact us - Progressus Bootstrap template</title>

	<link rel="shortcut icon" href="assets/images/gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="assets/css/main.css">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html">Online Booking Movie Ticket</a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li><a href="StaffHome.php">Home</a></li>
					<li><a href="Staff.php">Staff</a></li>
					<li><a href="Movie.php">Movie</a></li>		
					<li><a href="Theatre.php">Theatre</a></li>
					<li  class="active"><a href="Schedule.php">Schedule</a></li>
					<li><a href="LogOut.php">LogOut</a></li>					
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">

		

		<div class="row">
			
			<!-- Article main content -->
			<article class="col-sm-9 maincontent">
				<header class="page-header">
					<h1 class="page-title">Schedule Entry</h1>
				</header>
				
				
				<br>
	<form action="Schedule.php" method="GET">
		 <input type="hidden" name="action" value="add">
		<table>
			<tr>
				<td>Schedule ID</td>
				<td>
		<input name="txtscheduleid" type="text"  value="<?php echo AutoID('movie_schedule', 'ScheduleID','SCH-', 6) ?>" readonly/> 
				</td>
			</tr>
			<tr>
				<td>Purchase Date</td>
				<td>
	<input name="txtscheduledate" type="text" value="<?php echo date('Y-m-d')?>" readonly/>
				</td>
			</tr>
			<tr>
				<td>Start Date</td>
				<td>
	<input  name="txtstartdate" type="date">
				</td>
			</tr>
			<tr>
				<td>End Date</td>
				<td>
	<input  name="txtenddate" type="date">
				</td>
			</tr>
			<tr>
				<td>Start Time</td>
				<td>
				<input  name="txtstarttime" type="text">
				</td>
			</tr>
			<tr>
				<td>End Time</td>
				<td>
				<input  name="txtendtime" type="text">
				</td>
			</tr>
			<tr>
				<td>Movie Name</td>
				<td>
					<select name="cboMovieID">
						<option>Choose Movie Name</option>
						<?php 
							$select="SELECT * FROM Movie";
							$query=mysqli_query($connection,$select);
							$count=mysqli_num_rows($query);
							if($count>0)
							{
								for ($i=0; $i <$count ; $i++) 
								{ 
									$data=mysqli_fetch_array($query);
									$movieid=$data['MovieID'];
									$moviename=$data['MovieName'];
									echo "<option value='$movieid'>$moviename</option>";
								}
							}

						 ?>

					</select>
				</td>
			</tr>
			<tr>
				<td>Theatre Name</td>
				<td>
					<select name="cboTheatreID">
						<option>Choose Theatre Name</option>
						<?php 
							$select="SELECT * FROM Theatre";
							$query=mysqli_query($connection,$select);
							$count=mysqli_num_rows($query);
							if($count>0)
							{
								for ($i=0; $i <$count ; $i++) 
								{ 
									$data=mysqli_fetch_array($query);
									$TheatreID=$data['TheatreID'];
									$TheatreName=$data['TheatreName'];
									echo "<option value='$TheatreID'>$TheatreName</option>";
								}
							}

						 ?>

					</select>
				</td>
			</tr>
		
			<tr>
				<td></td>
				<td>
					 <input type="submit" name="btnAdd" value="Add">
				</td>
			</tr>
		</table>
		
<fieldset>
		<legend>Movie Schedule List</legend>
		<?php
		if (!isset($_SESSION['schedulefunction'])) 
		{
			echo "<p>No Schedule Record Found.</p>";
			exit();
		}
		?>
		<table align="center" border="1" cellpadding="3px">
			<tr>
				<th>Movie ID</th>
				<th>Movie Name</th>
				<th>Theatre Name</th>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Start Time</th>
				<th>End Time</th>
				<th>Action</th>
			</tr>
		<?php
		$size=count($_SESSION['schedulefunction']);
		for ($i=0; $i <$size ; $i++) 
		{ 
		$cboMovieID=$_SESSION['schedulefunction'][$i]['cboMovieID'];
	  	$MovieName=$_SESSION['schedulefunction'][$i]['MovieName'];
	  	$Movie=$_SESSION['schedulefunction'][$i]['MovieImage'];
	  	$cboTheatreID=$_SESSION['schedulefunction'][$i]['cboTheatreID'];
	  	$txtstartdate=$_SESSION['schedulefunction'][$i]['txtstartdate'];
	  	$txtstarttime=$_SESSION['schedulefunction'][$i]['txtstarttime'];
	  	$txtenddate=$_SESSION['schedulefunction'][$i]['txtenddate'];
	  	$txtendtime=$_SESSION['schedulefunction'][$i]['txtendtime'];
	  	$TheatreName=$_SESSION['schedulefunction'][$i]['TheatreName'];

			echo"<tr>";
			echo "<td>$cboMovieID</td>";
			echo "<td>$MovieName</td>";
			echo "<td>$TheatreName</td>";
			echo "<td>$txtstartdate</td>";
			echo "<td>$txtenddate</td>";
			echo "<td>$txtstarttime</td>";
			echo "<td>$txtendtime</td>";
			echo "<td><a href='Schedule.php?action=remove&cboMovieID=$cboMovieID'>Remove</a></td>";

			echo "</tr>";
		}
		?>	

	
			<tr>
			<td>Staff Name</td>
			<td>
				<select name="cboStaffID">
					<option>-----Select Staff Name------</option>
					<?php
					$query="Select * FROM staff";
					$ret=mysqli_query($connection,$query);
					$count=mysqli_num_rows($ret);

					for ($i=0; $i <$count ; $i++)
					{ 
						$arr=mysqli_fetch_array($ret);
						$StaffID=$arr['StaffID'];
						$staffname=$arr['StaffName'];
						echo"<option value='$StaffID'>" . $staffname ."</option>";
					}
					?>	
				</select>
			</td>
			<td>
				<input type="submit" name="btnsave" value="Save">
				</td>
			</tr>

	</table>
	</fieldset>
	</form>

			</article>
			<!-- /Article -->
			

		</div>
	</div>	<!-- /container -->
	


	<footer id="footer">

		<div class="footer1">
			<div class="container">
				<div class="row">
					
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contact</h3>
						<div class="widget-body">
							<p>+234 23 9873237<br>
								<a href="mailto:#">some.email@somewhere.com</a><br>
								<br>
								234 Hidden Pond Road, Ashland City, TN 37015
							</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Follow me</h3>
						<div class="widget-body">
							<p class="follow-me-icons clearfix">
								<a href=""><i class="fa fa-twitter fa-2"></i></a>
								<a href=""><i class="fa fa-dribbble fa-2"></i></a>
								<a href=""><i class="fa fa-github fa-2"></i></a>
								<a href=""><i class="fa fa-facebook fa-2"></i></a>
							</p>	
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Text widget</h3>
						<div class="widget-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi, dolores, quibusdam architecto voluptatem amet fugiat nesciunt placeat provident cumque accusamus itaque voluptate modi quidem dolore optio velit hic iusto vero praesentium repellat commodi ad id expedita cupiditate repellendus possimus unde?</p>
							<p>Eius consequatur nihil quibusdam! Laborum, rerum, quis, inventore ipsa autem repellat provident assumenda labore soluta minima alias temporibus facere distinctio quas adipisci nam sunt explicabo officia tenetur at ea quos doloribus dolorum voluptate reprehenderit architecto sint libero illo et hic.</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					
					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="simplenav">
								<a href="#">Home</a> | 
								<a href="about.html">About</a> |
								<a href="sidebar-right.html">Sidebar</a> |
								<a href="contact.html">Contact</a> |
								<b><a href="signup.html">Sign up</a></b>
							</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Copyright &copy; 2014, Your name. Designed by <a href="http://gettemplate.com/" rel="designer">gettemplate</a> 
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		




	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="assets/js/headroom.min.js"></script>
	<script src="assets/js/jQuery.headroom.min.js"></script>
	<script src="assets/js/template.js"></script>
	
	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?key=&amp;sensor=false&amp;extension=.js"></script> 
	<script src="assets/js/google-map.js"></script>
	

</body>
</html>