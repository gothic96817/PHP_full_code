<?php
function Add($cboMovieID,$cboTheatreID,$txtstartdate,$txtstarttime,$txtendtime,$txtenddate)
{
	$connect=mysqli_connect("localhost","root","","online_movie_ticket");
	$query="SELECT * FROM Movie WHERE MovieID='$cboMovieID'";
	$ret=mysqli_query($connect,$query);
	$count=mysqli_num_rows($ret);
	if ($count<1)
	 {
		echo "<p>NO Record Found.</p>";
		exit();
	}
	$arr=mysqli_fetch_array($ret);
	$MovieName=$arr['MovieName'];
	$MovieImage=$arr['Poster'];


	$query="SELECT * FROM Theatre WHERE TheatreID='$cboTheatreID'";
	$ret=mysqli_query($connect,$query);
	$arr=mysqli_fetch_array($ret);
	$TheatreName=$arr['TheatreName'];

	if(isset($_SESSION['schedulefunction'])) 
	{
	  $index=IndexOf($cboMovieID);
	  if($index==-1)	
	  {
	  	$size=count($_SESSION['schedulefunction']);

	  	$_SESSION['schedulefunction'][$size]['cboMovieID']=$cboMovieID;
	  	$_SESSION['schedulefunction'][$size]['MovieName']=$MovieName;
	  	$_SESSION['schedulefunction'][$size]['MovieImage']=$MovieImage;
	  	$_SESSION['schedulefunction'][$size]['cboTheatreID']=$cboTheatreID;
	  	$_SESSION['schedulefunction'][$size]['txtstartdate']=$txtstartdate;
	  	$_SESSION['schedulefunction'][$size]['txtstarttime']=$txtstarttime;
	  	$_SESSION['schedulefunction'][$size]['txtenddate']=$txtenddate;
	  	$_SESSION['schedulefunction'][$size]['txtendtime']=$txtendtime;
	  	$_SESSION['schedulefunction'][$size]['TheatreName']=$TheatreName;

	  
	}
}
	else
	{
		$_SESSION['schedulefunction']=array();
		$_SESSION['schedulefunction'][0]['cboMovieID']=$cboMovieID;
	  	$_SESSION['schedulefunction'][0]['MovieName']=$MovieName;
	  	$_SESSION['schedulefunction'][0]['MovieImage']=$MovieImage;
	  	$_SESSION['schedulefunction'][0]['cboTheatreID']=$cboTheatreID;
	  	$_SESSION['schedulefunction'][0]['txtstartdate']=$txtstartdate;
	  	$_SESSION['schedulefunction'][0]['txtstarttime']=$txtstarttime;
	  	$_SESSION['schedulefunction'][0]['txtenddate']=$txtenddate;
	  	$_SESSION['schedulefunction'][0]['txtendtime']=$txtendtime;
	  	$_SESSION['schedulefunction'][0]['TheatreName']=$TheatreName;
	}
	echo "<script>window.location='Schedule.php'</Script>";
}


function IndexOf($cboMovieID)
  {
  	if(!isset($_SESSION['schedulefunction']))
  	{
  		return -1;
  	}
  	$size=count($_SESSION['schedulefunction']);
  	if($size==0)
  	{
  		return -1;
  	}
  	for($i=0; $i<$size; $i++)
  	{
  		if($cboMovieID==$_SESSION['schedulefunction'][$i]['cboMovieID'])
     {
     	return $i;
     }
  	}
     return -1;
  }

  function Remove($cboMovieID)
{
	$index=IndexOf($cboMovieID);
	if($index!=-1)
	{
		unset($_SESSION['schedulefunction'][$index]);
		echo "<script>window.location='Schedule.php'</script>";
	}
}
?>