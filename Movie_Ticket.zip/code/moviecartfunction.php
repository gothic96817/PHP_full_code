<?php 
function Add($movieid,$BuyQuantity,$theatreid)
{
	$connect=mysqli_connect("localhost","root","","online_movie_ticket");
	$query="SELECT * FROM movie WHERE MovieID='$movieid'";
	$ret=mysqli_query($connect,$query);
	$count=mysqli_num_rows($ret);
	if ($count<1) 
	{
		echo "<p>No Record Found.</p>";
		exit();
	}
 $arr=mysqli_fetch_array($ret);
 $MovieName=$arr['MovieName'];
 $Poster=$arr['Poster'];

 $query="SELECT * FROM Theatre t, SeatType st 
 WHERE t.TheatreID=st.TheatreID
 AND t.TheatreID='$theatreid'";
	$ret=mysqli_query($connect,$query);
	$count=mysqli_num_rows($ret);
	$arr=mysqli_fetch_array($ret);
 	$Price=$arr['Price'];

 if (isset($_SESSION['ticketcart']))
 {
 	  $index=IndexOf($movieid);
	  if($index==-1)	
	  {
	  	$size=count($_SESSION['ticketcart']);

	  	$_SESSION['ticketcart'][$size]['movieid']=$movieid;
	  	$_SESSION['ticketcart'][$size]['MovieName']=$MovieName;
	  	$_SESSION['ticketcart'][$size]['Price']=$Price;
	  	$_SESSION['ticketcart'][$size]['BuyQuantity']=$BuyQuantity;
	  	$_SESSION['ticketcart'][$size]['Poster']=$Poster;

	  
	}
	else
	{
       
	  	$_SESSION['ticketcart'][$index]['BuyQuantity']+=$BuyQuantity;
	}	  	
 }
 else
 {
 	$_SESSION['ticketcart']=array();
 	$_SESSION['ticketcart'][0]['movieid']=$movieid;
	$_SESSION['ticketcart'][0]['MovieName']=$MovieName;
	$_SESSION['ticketcart'][0]['Price']=$Price;
	$_SESSION['ticketcart'][0]['BuyQuantity']=$BuyQuantity;
	$_SESSION['ticketcart'][0]['Poster']=$Poster;
 }
   echo "<script>window.location='schedulecart.php'</script>";
}

function IndexOf($movieid)
  {
  	if(!isset($_SESSION['ticketcart']))
  	{
  		return -1;
  	}
  	$size=count($_SESSION['ticketcart']);
  	if($size==0)
  	{
  		return -1;
  	}
  	for($i=0; $i<$size; $i++)
  	{
  		if($movieid==$_SESSION['ticketcart'][$i]['movieid'])
     {
     	return $i;
     }
  	}
     return -1;
  }


	function Remove($movieid)
{
	$index=IndexOf($movieid);
	if($index!=-1)
	{
		unset($_SESSION['ticketcart'][$index]);
		echo "<script>window.location='schedulecart.php'</script>";
	}
}
function CalculateTotalAmount()
{
	$totalamount=0;
	$size=count($_SESSION['ticketcart']);
	for ($i=0; $i <$size ; $i++)
	 { 
		$purchaseprice=$_SESSION['ticketcart'][$i]['Price'];
		$purchasequantity=$_SESSION['ticketcart'][$i]['BuyQuantity'];
		$totalamount=$totalamount + ($purchaseprice* $purchasequantity);
	}
	return $totalamount;
}

function CalculateTotalQuantity()
{
	$Qty=0;

	$size=count($_SESSION['ticketcart']);

	for ($i=0; $i <$size ; $i++) 
	{ 
		$quantity=$_SESSION['ticketcart'][$i]['BuyQuantity'];
		$Qty=$Qty + ($quantity);
	}
	return $Qty;
}
 ?>