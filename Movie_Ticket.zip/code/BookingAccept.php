<?php
include ('connect.php');
if (isset($_REQUEST['bid'])) 
{
	$bid=$_REQUEST['bid'];
	$Select="Update Booking set BookingStatus='confirm' where BookingID='$bid'";
	$query=mysqli_query($connection,$Select);
	if ($query) 
	{
		echo "<script>
		alert('Booking Confirm')
		window.location='staffhome.php'</script>";
	}
}
?>