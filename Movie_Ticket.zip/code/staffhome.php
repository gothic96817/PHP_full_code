<?php
	include('connect.php');

if(isset($_POST['btnSearch']))
{
	$rdoSearchType=$_POST['rdoSearchType'];

	if($rdoSearchType==1) 
	{
		$cboBookingID=$_POST['cboBookingID'];

		$Squery="SELECT b.*,c.CustomerID,c.CustomerName
				FROM Booking b,Customer c
					WHERE b.CustomerID=c.CustomerID
				 	AND b.BookingID='$cboBookingID'";
		$result=mysqli_query($connection,$Squery);
	}
	elseif ($rdoSearchType==2) 
	{
		$txtFrom=date('Y-m-d',strtotime($_POST['txtFrom']));
		$txtTo=date('Y-m-d',strtotime($_POST['txtTo']));

		$Squery="SELECT b.*,c.CustomerID,c.CustomerName
				FROM Booking b,Customer c 
				 WHERE b.BookingDate BETWEEN '$txtFrom' AND '$txtTo'
				 AND b.CustomerID=c.CustomerID";
		$result=mysqli_query($connection,$Squery);
	}
	else
	{
		$Squery="SELECT b.*,c.CustomerID,c.CustomerName
				FROM Booking b,Customer c 
				 WHERE b.CustomerID=c.CustomerID";
		$result=mysqli_query($connection,$Squery);
	}
}
elseif(isset($_POST['btnShowAll']))
{
	$Squery="SELECT b.*,c.CustomerID,c.CustomerName
				FROM Booking b,Customer c 
			WHERE b.CustomerID=c.CustomerID";
	$result=mysqli_query($connection,$Squery);
}
else
{
	$todayDate=date('Y-m-d');

	$Squery="SELECT b.*,c.CustomerID,c.CustomerName
				FROM Booking b,Customer c
				 WHERE b.BookingDate='$todayDate'
				 AND b.CustomerID=c.CustomerID";
	$result=mysqli_query($connection,$Squery);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author"      content="Sergey Pozhilov (GetTemplate.com)">
	
	<title>Login Form</title>

	<link rel="shortcut icon" href="assets/images/gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="assets/css/main.css">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html">Online Booking Movie Ticket</a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li  class="active"><a href="StaffHome.php">Home</a></li>
					<li><a href="Staff.php">Staff</a></li>
					<li><a href="Movie.php">Movie</a></li>		
					<li><a href="Theatre.php">Theatre</a></li>
					<li><a href="Schedule.php">Schedule</a></li>
					<li><a href="LogOut.php">LogOut</a></li>				
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">

		

		<div class="row">
			
			<!-- Article main content -->
			<article class="col-sm-9 maincontent">
				<header class="page-header">
					<h1 class="page-title">Ticket Booking Report</h1>
				</header>
				
<form action="Staffhome.php" method="post">
	 <fieldset>

<table border="1" width="100%">
	
<tr>
	<td>
		<input type="radio" name="rdoSearchType" value="1" checked />Search by Booking
		<br/>
		<select name="cboBookingID">
			<option>Choose BookingID</option>
			<?php  
			$query="SELECT b.*,c.CustomerID,c.CustomerName
					FROM Booking b,Customer c
					WHERE b.CustomerID=c.CustomerID";
			$ret=mysqli_query($connection,$query);
			$count=mysqli_num_rows($ret);

			for($i=0;$i<$count;$i++) 
			{ 
				$arr=mysqli_fetch_array($ret);
				$BookingID=$arr['BookingID'];
				$CustomerName=$arr['CustomerName'];	

				echo "<option value='$BookingID'>" . $BookingID . $CustomerName . "</option>";
			}

			?>
		</select>
	</td>

		<td>
		<input type="radio" name="rdoSearchType" value="2"/>Search by Date
		<br/>
		From:<input  type="date" name="txtFrom" value="<?php echo date('Y-m-d') ?>" />
		To  :<input  type="date" name="txtTo" value="<?php echo date('Y-m-d') ?>"  />
		</td>

		<td>
	<br/>
	<input type="submit" name="btnSearch" value="Search"/>
	<input type="submit" name="btnShowAll" value="Show All"/>

	</td>

</tr>
</table>
</fieldset>

<fieldset>
<legend>Search Results :</legend>
<?php  
	$count=mysqli_num_rows($result);

	if($count==0) 
	{
		echo "<p>No Booking Record Found.</p>";
		exit();
	}
	?>
	<table id="tableid" width="100%" class="display" align="center" border="1px">
	<thead>
	<tr>
		<th>Booking ID</th>
		<th>Booking Date</th>
		<th>Customer Name</th>
		<th>Total Amount</th>
		<th>Total Quantity</th>
		<th>Status</th>
		<th>Action</th>
	</tr>
	</thead>
	<tbody>	
	<?php
	for($i=0;$i<$count;$i++) 
	{
		$arr=mysqli_fetch_array($result);
		$BookingID=$arr['BookingID'];
		$CustomerName=$arr['CustomerName'];
		
		echo "<tr>";
			echo "<td>$BookingID</td>";
			echo "<td>" . $arr['BookingDate'] . "</td>";
			echo "<td>" . $CustomerName .  "</td>";	
			echo "<td>" . $arr['TotalPrice'] . "</td>";
			echo "<td>" . $arr['TotalUser'] . "</td>";
			echo "<td>" . $arr['BookingStatus'] . "</td>";
			echo "<td> 	 

		
		<a href='BookingAccept.php?bid=$BookingID' style='color:red'>Accept</a> 

				  </td>";
		echo "</tr>";
	}
	?>
	</tbody>
	</table>
</fieldset>
</form>


			</article>
			<!-- /Article -->
			

		</div>
	</div>	<!-- /container -->
	


	<footer id="footer">

		<div class="footer1">
			<div class="container">
				<div class="row">
					
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contact</h3>
						<div class="widget-body">
							<p>+234 23 9873237<br>
								<a href="mailto:#">some.email@somewhere.com</a><br>
								<br>
								234 Hidden Pond Road, Ashland City, TN 37015
							</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Follow me</h3>
						<div class="widget-body">
							<p class="follow-me-icons clearfix">
								<a href=""><i class="fa fa-twitter fa-2"></i></a>
								<a href=""><i class="fa fa-dribbble fa-2"></i></a>
								<a href=""><i class="fa fa-github fa-2"></i></a>
								<a href=""><i class="fa fa-facebook fa-2"></i></a>
							</p>	
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Text widget</h3>
						<div class="widget-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi, dolores, quibusdam architecto voluptatem amet fugiat nesciunt placeat provident cumque accusamus itaque voluptate modi quidem dolore optio velit hic iusto vero praesentium repellat commodi ad id expedita cupiditate repellendus possimus unde?</p>
							<p>Eius consequatur nihil quibusdam! Laborum, rerum, quis, inventore ipsa autem repellat provident assumenda labore soluta minima alias temporibus facere distinctio quas adipisci nam sunt explicabo officia tenetur at ea quos doloribus dolorum voluptate reprehenderit architecto sint libero illo et hic.</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					
					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="simplenav">
								<a href="#">Home</a> | 
								<a href="about.html">About</a> |
								<a href="sidebar-right.html">Sidebar</a> |
								<a href="contact.html">Contact</a> |
								<b><a href="signup.html">Sign up</a></b>
							</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Copyright &copy; 2014, Your name. Designed by <a href="http://gettemplate.com/" rel="designer">gettemplate</a> 
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		




	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="assets/js/headroom.min.js"></script>
	<script src="assets/js/jQuery.headroom.min.js"></script>
	<script src="assets/js/template.js"></script>
	
	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?key=&amp;sensor=false&amp;extension=.js"></script> 
	<script src="assets/js/google-map.js"></script>
	

</body>
</html>